@extends('front.app')
@section('title',"note")
@section('content')
<div style="padding: 120px 0px 30px 0px; background-color: #24355C;">
    <h1 class="text-white font-weight-bold text-center">Notes</h1>
</div>


@endsection